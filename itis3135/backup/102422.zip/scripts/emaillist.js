function email()  {
     window.prompt("Please enter your email to be added to out mailing list");
                        }