function refresh(){
    window.location.reload();
}