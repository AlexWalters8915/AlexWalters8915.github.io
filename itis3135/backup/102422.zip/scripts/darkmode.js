//change background to a dark color 

       function dark(){
    document.body.style.backgroundColor = 'black';
    document.getElementById("body").style.color = 'white';
    
}
       
    




