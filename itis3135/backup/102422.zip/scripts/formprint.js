//takes the values of specific parts of form needs to sort out how to pass in id  and have it work. something with this.id probably
    function showInput() {
       
       
       
       
       
        document.getElementById("displayy").innerHTML = 
                    document.getElementById("name-input").value;

                    document.getElementById("displayyy").innerHTML = 
                    document.getElementById("mood-input").value;
                   
                    document.getElementById("text").style.display = "block";
    }

    

    