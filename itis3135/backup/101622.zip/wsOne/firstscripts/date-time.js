//creates new date
var dt = new Date();
//takes element  and passes in the date  converted to local time on the browser
document.getElementById("datetime").innerHTML = dt.toLocaleString();




